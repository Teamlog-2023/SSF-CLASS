//필수 / 예제
let name = function() {
	console.log("TeamLog");
}
name();

//필수 / 예제
const hello = {
    print_hello : function(){
           console.log("Hello World");
   } 
};
let name = hello.print_hello();
//교재는 이렇게 말했지만 사실 name();만...
console.log(name);

//필수 / 실습 / 전체 직접 작성
const infor = {
    print_name : function(str){
           console.log(str);
   } 
};

let name = infor.print_name("TeamLog");
//교재는 이렇게 말했지만 사실 name();만...
console.log(name);

//선택 / 실습 / 전체 직접 작성 / 복붙 활용
const calculator = {
    plus : function(a,b) {
           return a + b;
    },
    minus : function(a,b) {
           return a - b;
    }, 
    multiply : function(a,b) {
           return a * b;
    }, 
  divide : function(a,b){
           return a / b;
  }
};
console.log(`plus : ${calculator.plus(5,5)}`);
console.log(`minus : ${calculator.minus(5,5)}`);
console.log(`multiply : ${calculator.multiply(5,5)}`);
console.log(`divide : ${calculator.divide(5,5)}`);

//필수 / 예제
let numbers = [4,3,2,1,5];

console.log(`length : ${numbers.length}`);
numbers.push(6);
console.log(numbers);
console.log(`length : ${numbers.length}`);
numbers.sort();
console.log(numbers);
numbers.reverse();
console.log(numbers);

//필수 / 예제
let number = 3.14159265359;
console.log(number.toFixed(2));

//필수 / 예제
let number = Math.random();
console.log(number);

//필수 / 실습
let number = (Math.______() * 10);
console.log(number._______(0));