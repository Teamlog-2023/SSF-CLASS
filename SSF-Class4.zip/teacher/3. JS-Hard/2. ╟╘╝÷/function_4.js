//함수 파트 네 번째 예제입니다.
//window 객체의 메서드인 alert를 설명합니다.

alert("TeamLog");