//document 출력 해보기

//querySelector 알아보기

//getElementById 알아보기

// DOM 생성 메소드
// let p = document._____________("p");     // p 태그 생성!
// p._________ = "teamlog";                 // p태그의 클래스 이름 설정!
// p._________ = "Hello World";             // p태그 내부 문자열 설정! 
// document.body.___________(p);            // p 태그 추가!


// 이벤트 핸들러 예제
// function convert() {
//     let name = document.getElementById("______");
//     name._______ = "TeamLog";
//     name.style.color = "yellow";
// }

//innerHTML vs textContent
// function InnerHTML() {
//     const element = document.getElementById('teamlog');
//     alert(element.innerHTML);
// } 
  
// function TextContent() {
//     const element = document.getElementById('teamlog');
//     alert(element.textContent);
// } 



// 최종 실습!
// let sword = 0;
// function change() {
//     if (sword == 15) {
//         alert("검을 전부 소유함!");
//     }
//     else {
//         sword_image = document._____________("img");     // 이미지 태그 생성
//         sword_image.____ = `./img/${sword += 1}.png`;    // 이미지 폴더에 있는 이미지에 대해서 접근하기
//         sword_image.____ = "200";                        // 이미지의 너비에 대해서 접근
//         document.body.___________(sword_image);          // 이미지 태그 추가
//     }
// }