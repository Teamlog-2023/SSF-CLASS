//document 출력 해보기

//querySelector

//getElementByd
// const p = document.getElementById('p');
// console.log(p);

// 속성 관련 메소드
let p = document.createElement("p");
document.body.appendChild(p);

// 태그 생성!
let p = document._____________("p");

//클래스 이름 설정!
p._________ = "teamlog";

// 내부 문자열 설정!
p.innerHTML = "Hello World";
document.body.appendChild(p);

//빈칸 필요!
// let sword = 1;
// function change() {
//     if (sword == 14) {
//         alert("검을 전부 소유함!");
//     }
//     else {
//         sword_image = document.createElement("img");
//         sword_image.src = `./img/${sword += 1}.png`;
//         sword_image.width = "200"
//         document.body.appendChild(sword_image);
//     }
// }