//템플릿 리터럴 예제 1 - 벡틱 사용법
console.log('Hello World'); 
console.log(`Hello World`);

//템플릿 리터럴 예제 2 - 달러 표기법
let month = 9;
let day = 2;

console.log(`오늘은 ${month}월 ${day}일 입니다.`);