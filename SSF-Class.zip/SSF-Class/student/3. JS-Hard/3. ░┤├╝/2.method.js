
//필수 / 예제
let numbers = [4,3,2,1,5];

console.log(`length : ${numbers.length}`);
numbers.push(6);
console.log(numbers);
console.log(`length : ${numbers.length}`);
numbers.sort();
console.log(numbers);
numbers.reverse();
console.log(numbers);


//필수 / 실습
let number = (Math.______() * 10);
console.log(number._______(0));