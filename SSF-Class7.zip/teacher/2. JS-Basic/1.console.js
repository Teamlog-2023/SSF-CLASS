//출력문 예시 
console.log('Hello World');
console.log("Hello World");
console.log(10);

//출력문 실습
console.log("TeamLog");
console.log('2023-09-02');