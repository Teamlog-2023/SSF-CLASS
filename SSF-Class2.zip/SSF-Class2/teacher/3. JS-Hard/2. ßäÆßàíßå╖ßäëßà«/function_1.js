//함수 파트 첫 번째 예제입니다.
//매개변수와 반환값이 없는 기본적인 함수를 설명합니다.

function myName() {
    console.log("TeamLog 김우진");
}

myName();