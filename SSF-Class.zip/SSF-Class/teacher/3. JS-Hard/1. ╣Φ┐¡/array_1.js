//배열 예제입니다.
//배열 선언 방법과 인덱싱, 그리고 문자열 인덱싱을 설명합니다.

let TeamLog = [];
// [1, "TeamLog", 3.14, "Hello", "world", 123, 1000]

let tl = TeamLog[1];
console.log(`${tl}`);

let str = "Hello";

console.log(str[4]);