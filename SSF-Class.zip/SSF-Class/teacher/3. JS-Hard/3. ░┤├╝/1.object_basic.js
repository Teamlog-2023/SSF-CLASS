// 필수 / 예제
// const TeamLog = {};

// 필수 / 예제
// const sunrin = { 
//     name : "TeamLog"
// };
// console.log(sunrin.name);

// 선택 / 실습
// const sunrin = { 
//     name : "TeamLog" , 
// topic : ["network" , "programming"],
//     people : 22 
// };
// console.log(sunrin.name);
// console.log(sunrin.topic);
// console.log(sunrin.people);

