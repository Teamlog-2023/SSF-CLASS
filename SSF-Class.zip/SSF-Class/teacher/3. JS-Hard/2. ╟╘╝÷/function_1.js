//함수 파트 첫 번째 예제입니다.
//매개변수와 반환값이 없는 기본적인 함수를 설명합니다.

function myName() {
    console.log("TeamLog 김우진"); // 내 이름을 출력해보세요.
}

myName(); // 함수를 호출해보세요.