//함수 파트 두 번째 예제입니다.
//매개변수가 있는 함수를 설명합니다.

function myName(str){
    console.log(`내 이름은... ${str} 이야!`);    
}

let name = "Kim woojin";
myName(name);