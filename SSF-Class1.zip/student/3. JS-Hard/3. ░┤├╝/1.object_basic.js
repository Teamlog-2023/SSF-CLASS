// 객체 선언
// TeamLog라는 객체
// const TeamLog = {};
// console.log(TeamLog);

// 프로퍼티
// sunrin이라는 객체에 프로퍼티 name
// const sunrin = { 
//     name : "TeamLog"
// };
// console.log(sunrin.name);

// 프로퍼티 접근법 1
// sunrin이라는 객체에 프로퍼티 name, topic, people
// const sunrin = { 
//     name : "TeamLog" , 
//     topic : ["network" , "programming"],
//     people : 22 
// };
// console.log(sunrin.name);
// console.log(sunrin.topic);
// console.log(sunrin.people);

// 프로퍼티 접근법 2 / 이런 것도 있다고 알아두시면 되겠습니다
// const sunrin = { 
//     name : "TeamLog" , 
// topic : ["network" , "programming"],
//     people : 22 
// };
// console.log(sunrin["name"]);
// console.log(sunrin['topic']);
// console.log(sunrin["people"]);

// 프로퍼티 삭제
// const sunrin = { 
//     name : "TeamLog" , 
//     topic : ["network" , "programming"],
//     people : 22 
// };
// delete sunrin.name;
// // delete sunrin["topic"];
// console.log(sunrin);