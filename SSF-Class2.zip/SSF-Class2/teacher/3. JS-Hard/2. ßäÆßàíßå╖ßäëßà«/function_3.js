//계산기 예제

function plus(a,b) {
    return a + b;
}
function minus(a,b) {
    return a - b;
}
function multiply(a,b) {
    return a * b;
}

function divide(a,b) {
    return a / b;
}

let plus_num = plus(5,5);
let minus_num = minus(5,5);
let multiply_num = multiply(5,5);
let divide_num = divide(5,5);

console.log(`plus : ${plus_num}`);
console.log(`minus : ${minus_num}`);
console.log(`multiply : ${multiply_num}`);
console.log(`divide : ${divide_num}`);