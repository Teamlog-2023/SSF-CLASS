//변수 선언 예시 & 자료형 예시
const club = "TeamLog";
let number = 123;
var pi = 3.14;

//키워드 실습
var teamlog = 10;
var teamlog = 15;
console.log(teamlog);

let team = 123;
let team = 123;

const log = "Hello";
const log = "World";


//변수 선언 실습 
let name = "TeamLog";
let day = "2023-09-02";

//변수 출력해보기 예시
let teamlog = "Hello World";
console.log(teamlog);