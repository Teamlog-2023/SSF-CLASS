// 필수 / 예제
// console.log(document);

// 필수 / 예제
// const p = document.querySelector('p');
// console.log(p)

// 필수 / 예제
// const p = document.getElementById('paragraph');
// console.log(p)

// 필수 / 예제
// let p = document.createElement("p");
// document.body.appendChild(p);

// 필수 / 실습
// 태그 생성!
// let p = document._____________("p");
// 클래스 이름 설정!
// p._________ = "teamlog";
// 내부 문자열 설정!
// p._________ = "Hello World";
// 만들어진 태그 추가!
// document.body.___________(p);

// 필수 / 실습
// let sword = 1;
// function change() {
//     if (sword == 14) {
//         alert("검을 전부 소유함!");
//     }
//     else {
//         // 이미지 태그 생성!
//         sword_image = document._____________("img");
//         // 소스 설정!
//         sword_image.___ = `./img/${sword+=1}.png`;
//         // 크기 설정!
//         sword_image._____ = "200"
//         // 만들어진 태그 추가!
//         document.body.___________(sword_image);
//     }
// }