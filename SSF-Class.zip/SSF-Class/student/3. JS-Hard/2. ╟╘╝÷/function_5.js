//함수 마지막 예제입니다.
//함수를 사용하여 간단한 코드를 작성 해 봅니다.

function login(user_password){ //password가 일치 할 경우 로그인 성공 메세지를 띄웁니다.
    const password = "2023TeamLog";
    if(____){ 
        return 1; //로그인 성공!
    }
    else{
        return 0; //로그인 실패!
    }
} 

let pw = "2023TeamLog";
let value = login(____);

if(____){
    alert("Success!");
}
else{
    alert("Failed!");
}