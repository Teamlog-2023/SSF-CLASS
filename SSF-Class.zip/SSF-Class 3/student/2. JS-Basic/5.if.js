//if문 예제 

//if문 실습

//else 예제

//else 실습

//else if 예제


// 시험 점수에 따라서 등급 출력하기 진행
// score >= 90 : A등급
// score >= 80 : B등급
// score >= 70 : C등급
// score >= 60 : D등급
// 그 외 : E등급

//else if 실습  
// let score = 95;

// if(_____){
// 	console.log("A");
// }
// _____(______) {
// 	console.log("B");
// }
// _____(_____){
// 	console.log("C");
// }
// _____(_____) {
// 	console.log("D");
// }
// else {
// 	console.log("E");
// }