//산술 연산 예제 
let number_1 = 5 + 5;
let number_2 = 5 - 5;
let number_3 = 5 * 5;
let number_4 = 5 / 5;
let number_5 = 5 % 5;

console.log(number_1 , number_2 , number_3 , number_4 , number_5);

//산술 연산 실습 + 교재 55p
let a = 20;
let b = 10;

console.log(`덧셈 : ${a + b}`);
console.log(`뺄셈 : ${a - b}`);
console.log(`곱셈 : ${a * b}`);
console.log(`나눗셈 : ${a / b}`);

//대입 연산 실습 
a += b; 
console.log(a);

a -= b; 
console.log(a);

a *= b; 
console.log(a);

a /= b; 
console.log(a);

//논리 연산 실습 & 참과거짓 개념 설명하기 & 부등호 예시들기
console.log(a >= b);
console.log(a <= b);
console.log(a != b);
console.log(a == b);