// 객체 선언
// TeamLog라는 객체
const sunrin = {
   
};

// 프로퍼티 접근법 - 객체의 이름.key


// 프로퍼티 접근법 - 객체의 이름["key"]
// console.log(sunrin["name"]);
// console.log(sunrin['topic']);
// console.log(sunrin["people"]);

// 프로퍼티 삭제