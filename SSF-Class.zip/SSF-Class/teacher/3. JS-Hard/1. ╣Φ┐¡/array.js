//배열 예제입니다.
//배열 선언 방법과 인덱싱, 그리고 문자열 인덱싱을 설명합니다.

let TeamLog = [1, "TeamLog", 3.14, "Hello", "world", 123, 1000]; // [1, "TeamLog", 3.14, "Hello", "world", 123, 1000] 값들을 넣어보세요.

let w = TeamLog[4]; // 변수 w의 값을 TeamLog 배열에서 찾아보세요.

let str = "Hello";
console.log(str[4]); // str 문자열에서 'o'를 찾아보세요.